const correctPassword = "Emin.1073.";

function checkPassword() {
  const input = document.getElementById("password").value;
  if (input === correctPassword) {
    document.getElementById("login").style.display = "none";
    document.getElementById("jarvis").style.display = "block";
  } else {
    document.getElementById("loginStatus").innerText = "Hatalı şifre!";
  }
}

function startListening() {
  const resultBox = document.getElementById("result");
  const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
  recognition.lang = "tr-TR";
  recognition.start();

  recognition.onresult = function(event) {
    const command = event.results[0][0].transcript.toLowerCase();
    resultBox.innerText = handleCommand(command);
  };

  recognition.onerror = function(event) {
    resultBox.innerText = "Dinleme hatası: " + event.error;
  };
}

function handleCommand(command) {
  if (command.includes("selam")) {
    return "Merhaba Stark, seni bekliyordum.";
  } else if (command.includes("saat")) {
    const now = new Date();
    return "Şu an saat " + now.getHours() + ":" + now.getMinutes();
  } else if (command.includes("gün") || command.includes("tarih")) {
    const now = new Date();
    return "Bugün " + now.toLocaleDateString("tr-TR", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  } else {
    return "Bu komutu anlayamadım.";
  }
}